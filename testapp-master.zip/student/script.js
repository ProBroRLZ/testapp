document.onload = function(){
	var logo = document.getElementById("logo")
	var container = document.getElementById("logocontainer")
	container.style.height = logo.clientHeight
}